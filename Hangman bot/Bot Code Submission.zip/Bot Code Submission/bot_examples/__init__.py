"""Reference Hangman bots."""
